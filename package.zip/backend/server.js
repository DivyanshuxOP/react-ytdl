const express = require('express');
const cors = require('cors');
const ytdl = require('@distube/ytdl-core');

const app = express();
const PORT = 5000;

app.use(cors());
app.get('/api/video-info', async (req, res) => {
    const { url } = req.query;
    if (!url) {
        return res.status(400).json({ error: 'Missing URL parameter.' });
    }

    try {
        const info = await ytdl.getInfo(url);
        console.log('Video Info:', info.formats); // Log formats for debugging
        const formats = info.formats.map((f) => ({
            format_id: f.itag,
            height: f.qualityLabel || 'Audio Only',
            format: f.container,
        }));
        res.json({
            title: info.videoDetails.title,
            thumbnail: info.videoDetails.thumbnails.pop().url,
            duration: info.videoDetails.lengthSeconds,
            formats,
        });
    } catch (err) {
        console.error('Error fetching video info:', err.message || err);
        res.status(500).json({ error: 'Failed to fetch video information.' });
    }
});


app.get('/api/download', async (req, res) => {
    const { url, format, quality } = req.query;

    if (!url || !format) {
        return res.status(400).json({ error: 'Missing URL or format parameter.' });
    }

    try {
        console.log(`Starting download: URL=${url}, Format=${format}, Quality=${quality}`);

        // Choose the correct filter and quality based on the parameters
        const options = {
            filter: format === 'mp3' ? 'audioonly' : 'video',
            quality: quality || 'highest',  // Default to 'highest' if no quality provided
        };

        // Ensure the video is downloaded with the correct options
        const stream = ytdl(url, options);

        // Set content headers to indicate file download
        const fileExtension = format === 'mp3' ? 'mp3' : 'mp4'; // Dynamically set file extension
        res.setHeader('Content-Disposition', `attachment; filename="${format === 'mp3' ? 'audio' : 'video'}.${fileExtension}"`);
        
        // Pipe the stream to the response
        stream.pipe(res);

        // Log any errors with the stream
        stream.on('error', (err) => {
            console.error('Error during stream:', err.message || err);
            res.status(500).json({ error: 'Failed to download video.' });
        });
    } catch (err) {
        console.error('Error during download:', err.message || err);
        res.status(500).json({ error: 'Failed to download video.' });
    }
});



app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
