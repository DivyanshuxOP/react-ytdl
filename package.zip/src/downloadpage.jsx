const express = require('express');
const ytdl = require('ytdl-core');
const app = express();
const PORT = 5000;

app.get('/api/video-info', async (req, res) => {
    const { url } = req.query;

    if (!url) {
        return res.status(400).json({ error: 'No URL provided' });
    }

    try {
        // Get video info using ytdl-core
        const info = await ytdl.getInfo(url);
        const formats = info.formats.map(f => ({
            format: f.container,
            quality: f.qualityLabel || 'Audio Only',
            itag: f.itag,
            height: f.height,
        }));

        res.json({
            title: info.videoDetails.title,
            thumbnail: info.videoDetails.thumbnails[info.videoDetails.thumbnails.length - 1].url,
            duration: info.videoDetails.lengthSeconds,
            formats: formats,
        });
    } catch (err) {
        console.error('Error fetching video info:', err);
        res.status(500).json({ error: 'Failed to fetch video information.' });
    }
});

app.get('/api/download', async (req, res) => {
    const { url, format, quality } = req.query;

    if (!url || !format) {
        return res.status(400).json({ error: 'Missing required parameters.' });
    }

    try {
        console.log(`Starting download for URL=${url}, Format=${format}, Quality=${quality}`);
        
        // Determine filter based on requested format
        const filter = format === 'mp3' ? 'audioonly' : 'videoandaudio'; // For MP3 or MP4
        const options = {
            filter: filter,
            quality: quality || 'highest',  // Default to highest if no quality provided
        };

        const stream = ytdl(url, options);

        res.setHeader('Content-Disposition', `attachment; filename="${format === 'mp3' ? 'audio' : 'video'}.${format}"`);
        stream.pipe(res);
    } catch (err) {
        console.error('Download error:', err);
        res.status(500).json({ error: 'Failed to download video.' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
