let link = '';

export const setLink = (newLink) => {
    link = newLink;
};

export const getLink = () => {
    return link;
};
